from setuptools import setup, find_packages

setup(
    name='PysparkProject',
    version='1.0.0',
    packages=find_packages(),
    url='https://github.com/Nkhatun123/PysparkProject',
    author='Nasima',
    author_email='khtun123nasima@gmail.com',
    description='PysparkProject Application',
)
